import React from 'react';
import {C} from '../theme';
import {Strand} from '../lib/yarn';

/** Tangan benang (lengan + telapak + jari) menghadap ke kanan. Titik (x, y) = pusat telapak. */
export const Hand: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <Strand d="M-330 0 L-50 0" w={44} color={C.terra} />
    <Strand d="M-30 0 L10 0" w={104} color={C.terra} />
    {[-38, -13, 13, 38].map((dy, i) => (
      <Strand key={i} d={`M20 ${dy} L${62 - Math.abs(dy) * 0.25} ${dy}`} w={24} color={C.terra} />
    ))}
    <Strand d="M-14 -48 L26 -84" w={24} color={C.terra} />
  </g>
);

/** Kasur dengan orang rebahan (siluet benang plum). Koordinat lokal: kasur menempel di puncak bola. */
export const BedPerson: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}>
    <Strand d="M-180 -28 L180 -28" w={34} color={C.amber} />
    <Strand d="M-160 -28 L-160 0" w={16} color={C.plum} ply={false} />
    <Strand d="M160 -28 L160 0" w={16} color={C.plum} ply={false} />
    <Strand d="M-180 -28 L-180 -80" w={16} color={C.plum} ply={false} />
    <Strand d="M-90 -63 L115 -63" w={36} color={C.plum} />
    <Strand d="M115 -63 L170 -75" w={28} color={C.plum} />
    <circle cx={-122} cy={-66} r={26} fill={C.plum} />
  </g>
);

/** Garis kecepatan: untai benang mendatar yang melintas berulang (deterministik dari frame). */
export const SpeedLines: React.FC<{frame: number; width: number; ys: number[]; speed?: number}> = ({
  frame,
  width,
  ys,
  speed = 34,
}) => (
  <g>
    {ys.map((y, i) => {
      const len = 150 + ((i * 53) % 110);
      const span = width + len * 2;
      const x = ((i * 211 + frame * (speed + i * 6)) % span) - len;
      return <Strand key={i} d={`M${x} ${y} L${x + len} ${y}`} w={12} color={i % 2 ? C.teal : C.terra} />;
    })}
  </g>
);

/** Tanda tanya dari benang. (x, y) = pusat; s = skala. */
export const Question: React.FC<{x: number; y: number; s: number; color?: string; rot?: number}> = ({
  x,
  y,
  s,
  color = C.amber,
  rot = 0,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <Strand d="M-34 -48 C-34 -96 38 -96 38 -48 C38 -14 0 -16 0 22" w={26} color={color} />
    <circle cx={0} cy={66} r={15} fill={color} />
  </g>
);
