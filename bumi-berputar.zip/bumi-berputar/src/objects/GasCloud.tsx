import React from 'react';
import {C} from '../theme';
import {D2R, Knot, poly, Strand} from '../lib/yarn';

/**
 * Awan gas dari benang: lengan spiral amber/terakota yang berputar (theta, derajat).
 * R = radius luar, flat = perbandingan sumbu pendek/panjang, grow = 0..1 (benang terurai dari inti).
 */
export const GasCloud: React.FC<{
  cx: number;
  cy: number;
  R: number;
  theta: number;
  flat?: number;
  grow?: number;
  arms?: number;
  strokeScale?: number;
}> = ({cx, cy, R, theta, flat = 0.42, grow = 1, arms = 6, strokeScale = 1}) => {
  const out: React.ReactNode[] = [];
  const turns = 2.1 * grow;
  for (let k = 0; k < arms; k++) {
    const pts: [number, number][] = [];
    const steps = 64;
    for (let s = 0; s <= steps; s++) {
      const u = (s / steps) * grow;
      const rho = R * (0.1 + 0.9 * Math.pow(u, 0.85));
      const ang = (turns * 2 * Math.PI * (s / steps)) * 0.75 + theta * D2R + (k * 2 * Math.PI) / arms;
      pts.push([cx + rho * Math.cos(ang), cy + rho * flat * Math.sin(ang)]);
    }
    const w = Math.max(5, R * 0.075 * strokeScale * (k % 2 ? 0.8 : 1));
    out.push(<Strand key={k} d={poly(pts)} w={w} color={k % 2 ? C.terra : C.amber} />);
  }
  // inti padat: cincin-cincin kecil
  const core = [0.1, 0.18, 0.27].map((f, i) => (
    <ellipse
      key={`c${i}`}
      cx={cx}
      cy={cy}
      rx={R * f}
      ry={R * f * flat}
      fill="none"
      stroke={i % 2 ? C.terra : C.amber}
      strokeWidth={Math.max(5, R * 0.05 * strokeScale)}
      strokeDasharray={`${R * 0.12} ${R * 0.05}`}
      strokeDashoffset={-theta * 1.4 * (i + 1)}
    />
  ));
  return (
    <g>
      {out}
      {core}
      <Knot cx={cx} cy={cy} r={Math.max(6, R * 0.07)} color={C.amber} turn={theta} />
    </g>
  );
};
