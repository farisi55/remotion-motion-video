import React from 'react';
import {C} from '../theme';
import {D2R, poly, Strand} from '../lib/yarn';

type Land = {lon: number; lat0: number; lat1: number; w: number; color: string};

// "Benua" = untai benang tebal di sepanjang garis bujur (bentuk disederhanakan).
const LAND: Land[] = [
  {lon: -95, lat0: 15, lat1: 60, w: 0.17, color: C.amber},
  {lon: -62, lat0: -45, lat1: 8, w: 0.15, color: C.terra},
  {lon: 15, lat0: -30, lat1: 35, w: 0.18, color: C.amber},
  {lon: 12, lat0: 42, lat1: 65, w: 0.1, color: C.terra},
  {lon: 85, lat0: 22, lat1: 62, w: 0.2, color: C.terra},
  {lon: 112, lat0: -4, lat1: 38, w: 0.14, color: C.amber},
  {lon: 135, lat0: -36, lat1: -16, w: 0.13, color: C.terra},
];

const MERIDIANS = [0, 45, 90, 135, 180, 225, 270, 315];
const LATS = [-60, -30, 0, 30, 60];

/** Titik di bola (lat, lon + putaran) -> koordinat layar; `vis` true bila menghadap kita. */
const proj = (cx: number, cy: number, r: number, lat: number, lon: number) => {
  const phi = lat * D2R;
  const lam = lon * D2R;
  return {x: cx + r * Math.cos(phi) * Math.sin(lam), y: cy - r * Math.sin(phi), vis: Math.cos(lam) > 0.02, depth: Math.cos(lam)};
};

const meridianPath = (cx: number, cy: number, r: number, lon: number, lat0 = -88, lat1 = 88) => {
  const segs: [number, number][][] = [];
  let run: [number, number][] = [];
  for (let lat = lat0; lat <= lat1 + 0.01; lat += 6) {
    const p = proj(cx, cy, r, lat, lon);
    if (p.vis) run.push([p.x, p.y]);
    else if (run.length) {
      segs.push(run);
      run = [];
    }
  }
  if (run.length) segs.push(run);
  return segs.filter((s) => s.length > 1).map(poly).join(' ');
};

let uid = 0;

/**
 * Bumi dari benang: bola biru dililit garis lintang & bujur, "benua" dari untai tebal.
 * `spin` (derajat) menggeser garis bujur sehingga tampak berputar. Poros miring seperti gasing.
 */
export const YarnGlobe: React.FC<{
  cx: number;
  cy: number;
  r: number;
  spin: number;
  tilt?: number;
  outline?: string;
  pins?: boolean;
  id?: string;
}> = ({cx, cy, r, spin, tilt = -23, outline = C.plum, pins = true, id}) => {
  const clipId = React.useMemo(() => id ?? `globe-clip-${uid++}`, [id]);
  const sw = r * 0.045;
  return (
    <g transform={`rotate(${tilt} ${cx} ${cy})`}>
      <defs>
        <clipPath id={clipId}>
          <circle cx={cx} cy={cy} r={r} />
        </clipPath>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill={C.teal} />
      <g clipPath={`url(#${clipId})`}>
        {LATS.map((lat) => {
          const y = cy - r * Math.sin(lat * D2R);
          const hw = r * Math.cos(lat * D2R);
          return <Strand key={lat} d={`M${cx - hw} ${y} L${cx + hw} ${y}`} w={sw * 1.3} color={C.plum} ply={false} opacity={0.22} cap="butt" />;
        })}
        {MERIDIANS.map((m) => (
          <Strand key={m} d={meridianPath(cx, cy, r, m + spin)} w={sw} color={C.cream} ply={false} opacity={0.75} />
        ))}
        {LAND.map((l, i) => {
          const lon = l.lon + spin;
          const depth = Math.cos(lon * D2R);
          if (depth <= 0.12) return null;
          const d = meridianPath(cx, cy, r, lon, l.lat0, l.lat1);
          if (!d) return null;
          return <Strand key={i} d={d} w={r * l.w * (0.4 + 0.6 * depth)} color={l.color} />;
        })}
      </g>
      <circle cx={cx} cy={cy} r={r - r * 0.02} fill="none" stroke={outline} strokeWidth={r * 0.06} />
      <circle
        cx={cx}
        cy={cy}
        r={r - r * 0.02}
        fill="none"
        stroke={C.plum}
        strokeOpacity={0.3}
        strokeWidth={r * 0.045}
        strokeDasharray={`${r * 0.01} ${r * 0.03}`}
      />
      {pins ? (
        <>
          <Strand d={`M${cx} ${cy - r} L${cx} ${cy - r - r * 0.16}`} w={r * 0.05} color={outline} ply={false} />
          <circle cx={cx} cy={cy - r - r * 0.18} r={r * 0.06} fill={C.terra} />
          <Strand d={`M${cx} ${cy + r} L${cx} ${cy + r + r * 0.16}`} w={r * 0.05} color={outline} ply={false} />
          <circle cx={cx} cy={cy + r + r * 0.18} r={r * 0.06} fill={C.terra} />
        </>
      ) : null}
    </g>
  );
};
