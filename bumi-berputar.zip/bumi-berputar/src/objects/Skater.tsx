import React from 'react';
import {C} from '../theme';
import {D2R, Knot, Strand} from '../lib/yarn';

/**
 * Penari es skating dari benang (viewBox 650x900, poros di x=325).
 * arms: 0 = tangan merentang, 1 = merapat. theta = sudut putar (derajat).
 */
export const Skater: React.FC<{arms: number; theta: number}> = ({arms, theta}) => {
  const cx = 325;
  const L = 230 + (62 - 230) * arms;
  const ph = theta * D2R;
  const shoulderY = 520;
  const hands = [1, -1].map((sgn) => ({
    sgn,
    x: cx + sgn * L * Math.cos(ph),
    y: shoulderY - 30 * arms + sgn * L * 0.16 * Math.sin(ph),
    depth: sgn * Math.sin(ph),
  }));
  const arm = (h: (typeof hands)[number]) => (
    <g key={h.sgn}>
      <Strand d={`M${cx + h.sgn * 24} ${shoulderY} L${h.x} ${h.y}`} w={26} color={C.plum} />
      <Knot cx={h.x} cy={h.y} r={20} color={C.plum} turn={theta} />
    </g>
  );
  const back = hands.filter((h) => h.depth < 0);
  const front = hands.filter((h) => h.depth >= 0);
  const ringRx = L * 1.08;

  return (
    <g transform="translate(325 560) scale(1.2) translate(-325 -620)">
      {[430, 520, 640].map((y, i) => (
        <ellipse
          key={y}
          cx={cx}
          cy={y}
          rx={ringRx}
          ry={ringRx * 0.17}
          fill="none"
          stroke={i % 2 ? C.terra : C.amber}
          strokeWidth={10}
          strokeDasharray="46 34"
          strokeDashoffset={-theta * 2.2 * (i + 1) * 0.5}
          strokeLinecap="round"
        />
      ))}
      <ellipse cx={cx} cy={810} rx={215} ry={36} fill="none" stroke={C.teal} strokeWidth={16} />
      <ellipse cx={cx} cy={810} rx={215} ry={36} fill="none" stroke={C.cream} strokeWidth={6} strokeDasharray="30 70" strokeDashoffset={-theta * 3} />
      {back.map(arm)}
      <Strand d={`M${cx} 810 L${cx} 650`} w={30} color={C.plum} />
      <path d={`M${cx - 8} 636 L${cx - 78} 728 L${cx + 78} 728 L${cx + 8} 636 Z`} fill={C.terra} />
      <Strand d={`M${cx - 8} 636 L${cx - 78} 728 L${cx + 78} 728 L${cx + 8} 636 Z`} w={14} color={C.terra} />
      <Strand d={`M${cx} 640 L${cx} 520`} w={66} color={C.terra} />
      <Strand d={`M${cx} 490 L${cx} 484`} w={44} color={C.plum} />
      <circle cx={cx} cy={452} r={40} fill={C.plum} />
      <Knot cx={cx} cy={402} r={15} color={C.amber} turn={theta} />
      {front.map(arm)}
    </g>
  );
};
