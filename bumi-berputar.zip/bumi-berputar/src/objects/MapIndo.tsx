import React from 'react';
import {C} from '../theme';
import {Knot, smoothClosed, Strand} from '../lib/yarn';

// Peta Indonesia sangat disederhanakan (viewBox 950x700).
const ISLANDS: [number, number][][] = [
  [[60, 100], [110, 80], [180, 150], [300, 260], [340, 330], [300, 345], [200, 270], [100, 190]], // Sumatra
  [[345, 398], [470, 382], [560, 396], [572, 422], [470, 428], [352, 422]], // Jawa
  [[380, 150], [440, 90], [540, 110], [580, 200], [560, 300], [480, 330], [400, 300], [360, 230]], // Kalimantan
  [[620, 160], [670, 140], [700, 190], [660, 230], [700, 300], [690, 350], [650, 310], [640, 240], [610, 200]], // Sulawesi
  [[770, 230], [830, 190], [900, 220], [935, 300], [900, 350], [830, 340], [790, 300]], // Papua
];
const DOTS: [number, number][] = [[600, 440], [650, 446], [700, 452], [750, 458], [725, 235], [742, 285]];

export const JAKARTA: [number, number] = [392, 396];

const planePath = 'M26 0 L-30 -20 L-14 0 L-30 20 Z';

/** Titik pada garis lurus a->b. */
const lerpP = (a: [number, number], b: [number, number], t: number): [number, number] => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

const EAST: [number, number] = [885, 470];
const WEST: [number, number] = [62, 235];

/**
 * Peta benang + dua pesawat dari Jakarta (timur & barat) + panah angin.
 * pe / pw = kemajuan pesawat timur / barat (0..1); wind = kemunculan panah angin (0..1); flow = geser aliran.
 */
export const MapIndo: React.FC<{pe: number; pw: number; wind: number; flow: number; mark: number}> = ({pe, pw, wind, flow, mark}) => {
  const ep = lerpP(JAKARTA, EAST, pe);
  const wp = lerpP(JAKARTA, WEST, pw);
  const plane = (p: [number, number], to: [number, number], color: string, key: string) => {
    const ang = (Math.atan2(to[1] - JAKARTA[1], to[0] - JAKARTA[0]) * 180) / Math.PI;
    return (
      <g key={key} transform={`translate(${p[0]} ${p[1]}) rotate(${ang})`}>
        <path d={planePath} fill={C.cream} stroke={C.plum} strokeWidth={8} strokeLinejoin="round" />
        <circle cx={-2} cy={0} r={6} fill={color} />
      </g>
    );
  };
  return (
    <g>
      {[560, 600, 640].map((y, i) => (
        <g key={y} opacity={wind}>
          <path
            d={`M60 ${y} q 40 -26 80 0 t 80 0 t 80 0 t 80 0 t 80 0 t 80 0 t 80 0 t 80 0 t 80 0 t 80 0`}
            fill="none"
            stroke={C.teal}
            strokeWidth={14}
            strokeLinecap="round"
            strokeDasharray="70 30"
            strokeDashoffset={-flow * (i + 1)}
          />
          <path d={`M852 ${y - 24} L890 ${y} L852 ${y + 24} Z`} fill={C.teal} />
        </g>
      ))}
      {ISLANDS.map((pts, i) => (
        <g key={i}>
          <path d={smoothClosed(pts)} fill={C.amber} />
          <Strand d={smoothClosed(pts)} w={16} color={C.terra} />
        </g>
      ))}
      {DOTS.map(([x, y], i) => (
        <Knot key={i} cx={x} cy={y} r={13} color={C.terra} turn={i * 40} />
      ))}
      {pe > 0 && <Strand d={`M${JAKARTA[0]} ${JAKARTA[1]} L${ep[0]} ${ep[1]}`} w={10} color={C.terra} />}
      {pw > 0 && <Strand d={`M${JAKARTA[0]} ${JAKARTA[1]} L${wp[0]} ${wp[1]}`} w={10} color={C.teal} />}
      <circle cx={JAKARTA[0]} cy={JAKARTA[1]} r={14 + 8 * mark} fill={C.plum} />
      {pe > 0 && plane(ep, EAST, C.terra, 'e')}
      {pw > 0 && plane(wp, WEST, C.teal, 'w')}
    </g>
  );
};
