// Semua posisi ditulis eksplisit (piksel pada kanvas 1080x1920).
// Tabel lengkap + hasil pemeriksaan tumpang tindih: docs/TATA-LETAK.md

export type Rect = {x: number; y: number; w: number; h: number};

export const W = 1080;
export const H = 1920;

/** Margin aman 6% di tiap sisi (65 px kiri/kanan, 115 px atas/bawah). */
export const SAFE: Rect = {x: 65, y: 115, w: 950, h: 1690};

/** Zona subtitle: tinggi tetap 18% kanvas (346 px), berakhir di margin aman bawah. */
export const SUB_ZONE: Rect = {x: 65, y: 1459, w: 950, h: 346};

export const LABEL_GAP = 10;
export const LABEL_H = 120;

/** Kotak label menempel tepat di bawah kotak objek, selebar objek. */
export const labelBox = (obj: Rect, h: number = LABEL_H): Rect => ({
  x: obj.x,
  y: obj.y + obj.h + LABEL_GAP,
  w: obj.w,
  h,
});

/** Kotak objek (zona objek di tengah atas dan slot-slot beat 4/6). */
export const BOX = {
  center: {x: 65, y: 130, w: 950, h: 1000} as Rect,
  skaterCenter: {x: 215, y: 150, w: 650, h: 900} as Rect,
  skaterLeft: {x: 65, y: 330, w: 410, h: 568} as Rect,
  cloudRight: {x: 605, y: 330, w: 410, h: 568} as Rect,
  map: {x: 65, y: 300, w: 950, h: 700} as Rect,
  closingEnd: {x: 290, y: 480, w: 500, h: 526} as Rect,
};

/** Jarak horizontal minimal antar slot yang tampil bersamaan: 8% lebar kanvas. */
export const MIN_SLOT_GAP = 0.08 * W;

export const lerpRect = (a: Rect, b: Rect, t: number): Rect => ({
  x: a.x + (b.x - a.x) * t,
  y: a.y + (b.y - a.y) * t,
  w: a.w + (b.w - a.w) * t,
  h: a.h + (b.h - a.h) * t,
});

/** Subtitle: tinggi huruf 80 px (4,17% tinggi kanvas), maksimal 2 baris x 17 karakter. */
export const SUB_FONT = 80;
export const SUB_LINE_H = 104;
export const SUB_MAX_CHARS = 17;
