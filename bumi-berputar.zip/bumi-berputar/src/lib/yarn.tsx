import React from 'react';
import {C} from '../theme';

/** Daftar titik -> path SVG. */
export const poly = (pts: [number, number][]): string =>
  pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');

/** Poligon tertutup -> kurva mulus (kuadratik lewat titik tengah sisi). */
export const smoothClosed = (pts: [number, number][]): string => {
  const n = pts.length;
  const mid = (a: [number, number], b: [number, number]) => `${((a[0] + b[0]) / 2).toFixed(1)} ${((a[1] + b[1]) / 2).toFixed(1)}`;
  let d = `M${mid(pts[n - 1], pts[0])}`;
  for (let i = 0; i < n; i++) {
    const p = pts[i];
    d += ` Q${p[0]} ${p[1]} ${mid(p, pts[(i + 1) % n])}`;
  }
  return d + ' Z';
};

/**
 * Benang tebal bertekstur rajut: satu garis tebal berwarna + lapisan "pilinan"
 * (garis putus-putus plum transparan) di atasnya.
 */
export const Strand: React.FC<{
  d: string;
  w: number;
  color: string;
  ply?: boolean;
  opacity?: number;
  cap?: 'round' | 'butt';
}> = ({d, w, color, ply = true, opacity = 1, cap = 'round'}) => (
  <g opacity={opacity}>
    <path d={d} fill="none" stroke={color} strokeWidth={w} strokeLinecap={cap} strokeLinejoin="round" />
    {ply && w >= 7 ? (
      <path
        d={d}
        fill="none"
        stroke={C.plum}
        strokeOpacity={0.3}
        strokeWidth={w * 0.7}
        strokeLinecap="butt"
        strokeLinejoin="round"
        strokeDasharray={`${(w * 0.16).toFixed(1)} ${(w * 0.46).toFixed(1)}`}
      />
    ) : null}
  </g>
);

/** Bola benang kecil (simpul / gumpalan / bintang). */
export const Knot: React.FC<{cx: number; cy: number; r: number; color: string; turn?: number}> = ({
  cx,
  cy,
  r,
  color,
  turn = 0,
}) => (
  <g transform={`rotate(${turn} ${cx} ${cy})`}>
    <circle cx={cx} cy={cy} r={r} fill={color} />
    <circle
      cx={cx}
      cy={cy}
      r={r * 0.62}
      fill="none"
      stroke={C.plum}
      strokeOpacity={0.32}
      strokeWidth={Math.max(1.5, r * 0.22)}
      strokeDasharray={`${(r * 0.5).toFixed(1)} ${(r * 0.55).toFixed(1)}`}
    />
  </g>
);

export const D2R = Math.PI / 180;
