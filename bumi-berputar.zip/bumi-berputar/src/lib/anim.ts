import {Easing, interpolate, spring} from 'remotion';
import {FPS} from './timing';

/** Lonjakan pegas: 0 sebelum `start`, lalu naik ke 1 (boleh melampaui sedikit). */
export const pop = (frame: number, start: number, damping = 11, stiffness = 150): number =>
  frame < start ? 0 : spring({frame: frame - start, fps: FPS, config: {damping, stiffness, mass: 0.7}});

/** Interpolasi mulus (ease in-out) dari a ke b, nilai dijepit. */
export const ease = (frame: number, a: number, b: number, from = 0, to = 1): number =>
  interpolate(frame, [a, b], [from, to], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

/** Denyut meredam: nilai 1 saat `start`, meluruh ke 0. */
export const pulse = (frame: number, start: number, decay = 9): number =>
  frame < start ? 0 : Math.exp(-(frame - start) / decay);

/** Skala masuk (pegas) x keluar (ease-in) untuk satu slot objek dalam satu beat. */
export const slotScale = (frame: number, duration: number, enter = 14, exit = 12): number => {
  const inn = pop(frame, 0, 13, 120);
  const out = interpolate(frame, [duration - exit, duration], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  return Math.min(inn, enter > 0 ? 1.08 : 1) * out;
};
