import {AUDIO_OFFSET, SRT_RAW} from '../data/captions';
import {SUB_MAX_CHARS} from '../layout';

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/** Detik -> frame, dibulatkan. AUDIO_OFFSET ikut dihitung. */
export const toFrame = (sec: number): number => Math.max(0, Math.round((sec + AUDIO_OFFSET) * FPS));

// ---------- SRT -> cue ----------
type Cue = {start: number; end: number; text: string};

const parseTime = (s: string): number => {
  const m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(s);
  if (!m) throw new Error(`Format waktu SRT tidak valid: ${s}`);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, '')
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split('\n').map((l) => l.trim());
      const t = lines.findIndex((l) => l.includes('-->'));
      const [a, b] = lines[t].split('-->');
      return {start: parseTime(a), end: parseTime(b), text: lines.slice(t + 1).join(' ')};
    });

// ---------- cue -> kata (dibagi proporsional jumlah huruf) ----------
export type Word = {
  text: string;
  norm: string;
  start: number; // detik (sudah + AUDIO_OFFSET)
  end: number;
  startF: number;
  endF: number;
};

const weight = (w: string) => Math.max(1, (w.match(/[\p{L}\p{N}]/gu) ?? []).length);
export const normalize = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

export const buildWords = (cues: Cue[]): Word[] => {
  const out: Word[] = [];
  for (const cue of cues) {
    const tokens = cue.text.split(/\s+/).filter(Boolean);
    const total = tokens.reduce((s, t) => s + weight(t), 0);
    let acc = 0;
    for (const t of tokens) {
      const s = cue.start + ((cue.end - cue.start) * acc) / total;
      acc += weight(t);
      const e = cue.start + ((cue.end - cue.start) * acc) / total;
      out.push({
        text: t,
        norm: normalize(t),
        start: s + AUDIO_OFFSET,
        end: e + AUDIO_OFFSET,
        startF: toFrame(s),
        endF: toFrame(e),
      });
    }
  }
  return out;
};

export const WORDS: Word[] = buildWords(parseSrt(SRT_RAW));
const LAST_WORD_END = WORDS[WORDS.length - 1].end;

/** Durasi total = kata terakhir selesai + 1 detik. */
export const TOTAL_FRAMES = Math.round((LAST_WORD_END + 1) * FPS);

// ---------- beat ----------
export const findWord = (norms: string[], from = 0): number => {
  for (let i = from; i <= WORDS.length - norms.length; i++) {
    if (norms.every((n, k) => WORDS[i + k].norm === n)) return i;
  }
  throw new Error(`Kata "${norms.join(' ')}" tidak ditemukan di SRT setelah indeks ${from}`);
};

const BEAT_DEFS: {id: string; anchor: string[] | null}[] = [
  {id: 'hook', anchor: null},
  {id: 'masalah', anchor: ['tapi', 'kenapa']},
  {id: 'inti', anchor: ['jawabannya']},
  {id: 'contoh', anchor: ['bayangkan']},
  {id: 'dampak', anchor: ['putaran', 'ini']},
  {id: 'penutup', anchor: ['bumi', 'muter']},
];

export type Beat = {id: string; wordIdx: number; from: number; duration: number};

export const BEATS: Beat[] = (() => {
  let prev = 0;
  const starts = BEAT_DEFS.map((d) => {
    if (!d.anchor) return {wordIdx: 0, from: 0};
    const idx = findWord(d.anchor, prev);
    prev = idx;
    return {wordIdx: idx, from: WORDS[idx].startF};
  });
  return BEAT_DEFS.map((d, i) => {
    const end = i + 1 < starts.length ? starts[i + 1].from : TOTAL_FRAMES;
    return {id: d.id, wordIdx: starts[i].wordIdx, from: starts[i].from, duration: end - starts[i].from};
  });
})();

/** Frame (relatif terhadap awal beat) saat kata mulai diucapkan. */
export const at = (beat: number, ...norms: string[]): number => {
  const b = BEATS[beat];
  return WORDS[findWord(norms, b.wordIdx)].startF - b.from;
};
/** Frame (relatif beat) saat kata selesai diucapkan. */
export const atEnd = (beat: number, ...norms: string[]): number => {
  const b = BEATS[beat];
  return WORDS[findWord(norms, b.wordIdx)].endF - b.from;
};

// ---------- halaman subtitle (maks. 2 baris x SUB_MAX_CHARS) ----------
export type SubPage = {lines: number[][]; startF: number; endF: number};

export const SUB_PAGES: SubPage[] = (() => {
  const pages: {lines: number[][]}[] = [];
  let cur: number[][] = [[]];
  const lineLen = (l: number[]) => l.reduce((s, i, k) => s + WORDS[i].text.length + (k ? 1 : 0), 0);
  const flush = () => {
    if (cur[0].length) pages.push({lines: cur});
    cur = [[]];
  };
  WORDS.forEach((w, i) => {
    const line = cur[cur.length - 1];
    const fits = (l: number[]) => lineLen([...l, i]) <= SUB_MAX_CHARS;
    if (line.length === 0 || fits(line)) line.push(i);
    else if (cur.length === 1) cur.push([i]);
    else {
      flush();
      cur[0].push(i);
    }
    if (/[.?!]$/.test(w.text)) flush();
  });
  flush();
  return pages.map((p, k) => {
    const first = p.lines[0][0];
    const next = pages[k + 1]?.lines[0][0];
    const startF = WORDS[first].startF;
    const endF = next !== undefined ? WORDS[next].startF : Math.round((LAST_WORD_END + 0.5) * FPS);
    return {lines: p.lines, startF, endF};
  });
})();
