import React from 'react';
import {Composition} from 'remotion';
import {BumiBerputar} from './BumiBerputar';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './lib/timing';

// Durasi total dihitung dari data SRT (kata terakhir selesai + 1 detik), bukan angka tetap.
export const RemotionRoot: React.FC = () => (
  <Composition id="BumiBerputar" component={BumiBerputar} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
