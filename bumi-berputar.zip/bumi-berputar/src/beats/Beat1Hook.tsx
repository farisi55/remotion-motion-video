import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX} from '../layout';
import {Slot} from '../components/Slot';
import {YarnGlobe} from '../objects/YarnGlobe';
import {BedPerson, SpeedLines} from '../objects/Figures';
import {BEATS, at} from '../lib/timing';
import {ease, pop, pulse, slotScale} from '../lib/anim';

/** Beat 1 - Hook: orang rebahan di kasur di atas bumi benang yang berputar; angka 1.600 km/jam berdenyut. */
export const Beat1Hook: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[0].duration;
  const tFast = at(0, 'melaju');
  const tNum = at(0, '1600');
  const tBuzz = at(0, 'ngebut');

  // Putaran bumi dihitung dengan integrasi per frame; makin cepat saat kata "melaju".
  let theta = 0;
  for (let i = 0; i < f; i++) theta += 1.4 * ease(i, tFast, tFast + 20, 1, 1.9);

  const labelScale = pop(f, tNum) * (1 + 0.04 * Math.sin(f * 0.3) + 0.14 * pulse(f, tBuzz));
  const bob = 3 * Math.sin(f * 0.9);

  return (
    <Slot
      box={BOX.center}
      viewBox={[950, 1000]}
      label={f >= tNum ? '1.600 km/jam' : null}
      labelSize={76}
      labelScale={labelScale}
      scale={slotScale(f, dur)}
      spin={ease(f, dur - 12, dur) * 140}
    >
      <SpeedLines frame={f} width={950} ys={[120, 165, 210, 255, 300]} speed={ease(f, tFast, tFast + 20, 26, 44)} />
      <YarnGlobe cx={475} cy={620} r={330} spin={theta} pins={false} />
      <BedPerson x={475} y={290 + bob} />
    </Slot>
  );
};
