import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX, lerpRect} from '../layout';
import {Slot} from '../components/Slot';
import {YarnGlobe} from '../objects/YarnGlobe';
import {Knot} from '../lib/yarn';
import {BEATS, at} from '../lib/timing';
import {ease, pop} from '../lib/anim';
import {C} from '../theme';

/** Beat 6 - Penutup: kamera menjauh, bumi menyusut jadi titik kecil yang masih berputar; layar meredup. */
export const Beat6Penutup: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[5].duration;
  const tLabel = at(5, 'terus');

  const away = ease(f, 10, dur - 30);
  const box = lerpRect(BOX.center, BOX.closingEnd, away);
  const r = 300 + (18 - 300) * away;
  const dim = 1 - 0.8 * ease(f, dur - 45, dur);
  const theta = f * 1.2;

  return (
    <Slot
      box={box}
      viewBox={[950, 1000]}
      label={f >= tLabel ? 'Masih berputar.' : null}
      labelSize={52}
      labelScale={pop(f, tLabel)}
      scale={pop(f, 0, 13, 120)}
    >
      <g opacity={dim}>
        {r > 34 ? <YarnGlobe cx={475} cy={500} r={r} spin={theta} outline={C.cream} /> : <Knot cx={475} cy={500} r={Math.max(18, r)} color={C.teal} turn={theta} />}
      </g>
    </Slot>
  );
};
