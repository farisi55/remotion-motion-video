import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX, lerpRect} from '../layout';
import {Slot} from '../components/Slot';
import {Skater} from '../objects/Skater';
import {GasCloud} from '../objects/GasCloud';
import {MapIndo} from '../objects/MapIndo';
import {BEATS, at, atEnd} from '../lib/timing';
import {ease, pop, pulse} from '../lib/anim';

/**
 * Beat 4 - Contoh. Urutan (tidak pernah tumpang tindih):
 *  a) penari di tengah -> b) penari bergeser ke slot kiri -> c) awan masuk di slot kanan
 *  -> keduanya keluar -> d) peta + dua pesawat + panah angin.
 */
export const Beat4Contoh: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[3].duration;
  const tClose = at(3, 'dirapatkan');
  const tAwan = at(3, 'awan');
  const tDan = at(3, 'dan');
  const tPlane = at(3, 'pesawat');
  const tWind = at(3, 'angin');
  const tEast = at(3, 'dibanding');
  const tWestEnd = atEnd(3, 'barat') + 10;

  // Penari: tangan merapat -> radius putar mengecil -> putaran makin cepat (dibatasi agar tidak strobo).
  const armsAt = (i: number) => ease(i, tClose, tClose + 26);
  let theta = 0;
  for (let i = 0; i < f; i++) {
    const L = 230 + (62 - 230) * armsAt(i);
    theta += Math.min(18, 3 * Math.pow(230 / L, 2));
  }
  const arms = armsAt(f);

  const exitPair = 1 - ease(f, tDan - 4, tDan + 8);
  const moveT = ease(f, tAwan, tAwan + 16);
  const skaterBox = lerpRect(BOX.skaterCenter, BOX.skaterLeft, moveT);
  const skaterScale = pop(f, 0, 13, 120) * exitPair;

  // Awan di slot kanan: baru masuk setelah penari selesai bergeser.
  const tCloud = tAwan + 18;
  const cloudR = ease(f, tCloud + 6, tCloud + 50, 175, 62);
  let cTheta = 0;
  for (let i = 0; i < f; i++) cTheta += Math.min(8, 0.6 * Math.pow(175 / ease(i, tCloud + 6, tCloud + 50, 175, 62), 2));
  const cloudScale = pop(f, tCloud, 13, 120) * exitPair;

  // Peta: masuk setelah penari & awan selesai keluar; keluar di akhir beat.
  const tMap = tDan + 10;
  const mapScale = pop(f, tMap, 13, 120) * (1 - ease(f, dur - 12, dur));
  const pe = ease(f, tPlane + 6, tEast);
  const pw = ease(f, tPlane + 6, tWestEnd);

  return (
    <>
      {f < tDan + 10 && (
        <Slot box={skaterBox} viewBox={[650, 900]} label="Penari" labelSize={76} scale={skaterScale} spin={(1 - exitPair) * 140}>
          <Skater arms={arms} theta={theta} />
        </Slot>
      )}
      {f >= tCloud && f < tDan + 10 && (
        <Slot box={BOX.cloudRight} viewBox={[410, 568]} label="Awan" labelSize={76} scale={cloudScale} spin={(1 - exitPair) * 140}>
          <GasCloud cx={205} cy={284} R={cloudR} theta={cTheta} flat={0.42 + 0.3 * ease(f, tCloud + 6, tCloud + 50)} grow={ease(f, tCloud, tCloud + 14)} strokeScale={1.2} />
        </Slot>
      )}
      {f >= tMap && (
        <Slot box={BOX.map} viewBox={[950, 700]} label="Soekarno-Hatta" labelSize={76} scale={mapScale} spin={ease(f, dur - 12, dur) * 140}>
          <MapIndo pe={pe} pw={pw} wind={ease(f, tWind, tWind + 15)} flow={f * 4} mark={pulse(f, tPlane, 12)} />
        </Slot>
      )}
    </>
  );
};
