import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX} from '../layout';
import {Slot} from '../components/Slot';
import {YarnGlobe} from '../objects/YarnGlobe';
import {Strand} from '../lib/yarn';
import {BEATS, at, atEnd} from '../lib/timing';
import {ease, pop, slotScale} from '../lib/anim';
import {C} from '../theme';
import {interpolateColors} from 'remotion';

const CX = 475;
const CY = 500;
const R = 310;

const halfDisc = (side: 1 | -1) => `M${CX} ${CY - R} A${R} ${R} 0 0 ${side === 1 ? 1 : 0} ${CX} ${CY + R} Z`;

/** Arus laut & angin: busur benang melengkung di permukaan, mengalir (geser dash per frame). */
const FLOW: {dy: number; bow: number; color: string}[] = [
  {dy: -170, bow: -46, color: C.cream},
  {dy: 10, bow: 40, color: C.amber},
  {dy: 170, bow: -40, color: C.cream},
];

/** Beat 5 - Dampak: bumi separuh terang separuh gelap, jam menghitung 24 jam, lalu berhenti (panas vs beku). */
export const Beat5Dampak: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[4].duration;
  const tSiang = at(4, 'siang');
  const tSatu = at(4, 'satu');
  const tJamEnd = atEnd(4, 'jam');
  const tFlow = at(4, 'lautan');
  const tFreeze = at(4, 'tanpa');
  const tLabel2 = at(4, 'panggang');

  const win = Math.max(1, tJamEnd - tSatu);
  const slow = (i: number) => 1 - ease(i, tFreeze, tFreeze + 25);
  let theta = 0;
  for (let i = 0; i < f; i++) theta += (1.2 + (i >= tSatu && i < tJamEnd ? 360 / win : 0)) * slow(i);

  const hours = Math.min(24, Math.floor((24 * Math.max(0, f - tSatu)) / win));
  const label = f >= tLabel2 ? 'Berhenti' : f >= tSatu ? `${hours} jam` : f >= tSiang ? 'Siang malam' : null;
  const labelStart = f >= tLabel2 ? tLabel2 : f >= tSatu ? tSatu : tSiang;

  const hot = ease(f, tFreeze + 10, tFreeze + 40);
  const dayColor = interpolateColors(hot, [0, 1], [C.amber, C.terra]);
  const nightColor = interpolateColors(hot, [0, 1], [C.plum, C.teal]);
  const jitter = hot * 4 * Math.sin(f * 2.3);
  const flowIn = ease(f, tFlow, tFlow + 16) * (1 - ease(f, tFreeze, tFreeze + 20));

  return (
    <Slot
      box={BOX.center}
      viewBox={[950, 1000]}
      label={label}
      labelSize={76}
      labelScale={0.92 + 0.08 * pop(f, labelStart, 12, 170) + (f >= tSatu && f < tJamEnd + 6 ? 0.04 * Math.sin(f) : 0)}
      scale={slotScale(f, dur)}
      spin={ease(f, dur - 12, dur) * 140}
    >
      <YarnGlobe cx={CX} cy={CY} r={R} spin={theta} />
      <path d={halfDisc(-1)} fill={nightColor} opacity={0.5 + 0.35 * hot} />
      <g transform={`translate(${jitter} 0)`}>
        <path d={halfDisc(1)} fill={dayColor} opacity={0.12 + 0.6 * hot} />
      </g>
      {flowIn > 0.02 &&
        FLOW.map((a, i) => {
          const hw = Math.sqrt(R * R - a.dy * a.dy) * 0.78;
          const y = CY + a.dy;
          const d = `M${CX - hw} ${y} Q${CX} ${y + a.bow} ${CX + hw} ${y}`;
          return (
            <g key={i} opacity={flowIn}>
              <path d={d} fill="none" stroke={a.color} strokeWidth={16} strokeLinecap="round" strokeDasharray="56 34" strokeDashoffset={-f * 3} />
              <path d={`M${CX + hw - 4} ${y - 24} L${CX + hw + 30} ${y} L${CX + hw - 4} ${y + 24} Z`} fill={a.color} />
            </g>
          );
        })}
      {/* sisi panas: sinar benang memanjang & bergetar; sisi beku: kristal kaku */}
      {Array.from({length: 7}, (_, i) => {
        const a = ((-60 + i * 20) * Math.PI) / 180;
        const len = 34 + 46 * hot;
        const r0 = R + 26;
        return (
          <Strand
            key={`s${i}`}
            d={`M${CX + r0 * Math.cos(a) + jitter} ${CY + r0 * Math.sin(a)} L${CX + (r0 + len) * Math.cos(a) + jitter} ${CY + (r0 + len) * Math.sin(a)}`}
            w={14}
            color={i % 2 ? C.terra : C.amber}
          />
        );
      })}
      {Array.from({length: 5}, (_, i) => {
        const a = ((120 + i * 24) * Math.PI) / 180;
        const x = CX + (R + 52) * Math.cos(a);
        const y = CY + (R + 52) * Math.sin(a);
        const s = 14 + 10 * hot;
        return (
          <g key={`k${i}`}>
            <Strand d={`M${x - s} ${y} L${x + s} ${y}`} w={8} color={C.teal} ply={false} />
            <Strand d={`M${x} ${y - s} L${x} ${y + s}`} w={8} color={C.teal} ply={false} />
          </g>
        );
      })}
    </Slot>
  );
};
