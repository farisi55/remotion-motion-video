import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX} from '../layout';
import {Slot} from '../components/Slot';
import {YarnGlobe} from '../objects/YarnGlobe';
import {GasCloud} from '../objects/GasCloud';
import {Knot} from '../lib/yarn';
import {BEATS, at} from '../lib/timing';
import {ease, pop, slotScale} from '../lib/anim';
import {C} from '../theme';

const R0 = 400;
const R1 = 95;
const CX = 475;
const CY = 500;

/** Beat 3 - Inti: awan gas benang runtuh, makin kecil makin kencang, menyatu jadi bumi yang terus berputar. */
export const Beat3Inti: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[2].duration;
  const tLabel = at(2, 'miliar');
  const tA = at(2, 'runtuh');
  const tF = at(2, 'terbentuk');

  const radius = (i: number) => ease(i, tA, tF - 10, R0, R1) * (1 + 0.012 * Math.sin(i * 0.1));
  // Momentum sudut tetap: makin kecil radius, makin cepat putaran (dibatasi 6 derajat/frame agar tidak "strobo").
  let theta = 0;
  for (let i = 0; i < f; i++) theta += Math.min(6, 0.5 * Math.pow(R0 / radius(i), 2));

  const R = radius(f);
  const merge = ease(f, tF - 12, tF + 6);
  const collapse = ease(f, tA, tF - 10);
  const clumps = Array.from({length: 7}, (_, i) => {
    const frac = (i * 0.37) % 1;
    const rho = R * (0.55 + 0.3 * frac) * (1 - merge);
    const ang = ((theta * 1.1 + (i * 360) / 7) * Math.PI) / 180;
    return {x: CX + rho * Math.cos(ang), y: CY + rho * (0.42 + 0.58 * collapse) * Math.sin(ang), r: 15 + 7 * frac, i};
  });
  const globeR = 175 * pop(f, tF, 12, 110);

  return (
    <Slot
      box={BOX.center}
      viewBox={[950, 1000]}
      label={f >= tLabel ? '4,5 miliar' : null}
      labelSize={76}
      labelScale={pop(f, tLabel)}
      scale={slotScale(f, dur)}
      spin={ease(f, dur - 12, dur) * 140}
    >
      {f < tF + 14 && (
        <GasCloud cx={CX} cy={CY} R={R} theta={theta} flat={0.42 + 0.5 * collapse} grow={ease(f, 0, 26)} strokeScale={1 + 0.4 * collapse} />
      )}
      {f >= tA && f < tF + 8 && clumps.map((c) => <Knot key={c.i} cx={c.x} cy={c.y} r={c.r} color={c.i % 2 ? C.terra : C.amber} turn={theta} />)}
      {f >= tF - 2 && <YarnGlobe cx={CX} cy={CY} r={globeR} spin={theta} outline={C.cream} />}
    </Slot>
  );
};
