import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BOX} from '../layout';
import {Slot} from '../components/Slot';
import {YarnGlobe} from '../objects/YarnGlobe';
import {Hand, Question} from '../objects/Figures';
import {BEATS, at} from '../lib/timing';
import {ease, pop, pulse, slotScale} from '../lib/anim';
import {C} from '../theme';

const MARKS: {x: number; y: number; s: number; word: string}[] = [
  {x: 140, y: 250, s: 1.0, word: 'kenapa'},
  {x: 820, y: 240, s: 1.05, word: 'mesin'},
  {x: 95, y: 700, s: 0.9, word: 'tali'},
  {x: 850, y: 690, s: 0.95, word: 'merasa'},
  {x: 475, y: 85, s: 0.8, word: 'siapa'},
];

/** Beat 2 - Masalah: bumi diam, tanda tanya benang bermunculan, tangan mendorong lalu mundur bingung. */
export const Beat2Masalah: React.FC = () => {
  const f = useCurrentFrame();
  const dur = BEATS[1].duration;
  const tPush = at(1, 'mendorong');
  const tBack = at(1, 'pertama');
  const tLabel = at(1, 'siapa');

  // Tangan: masuk, mendorong (bumi hanya bergeser sedikit lalu memantul), lalu mundur sambil menggeleng.
  const approach = ease(f, tPush - 26, tPush, -60, 108);
  const push = ease(f, tPush, tPush + 8, 0, 16) - ease(f, tPush + 8, tPush + 26, 0, 16);
  const retreat = ease(f, tBack, tBack + 30, 0, 330);
  const handX = approach + push - retreat;
  const confused = f > tBack ? 12 * Math.sin((f - tBack) * 0.55) * Math.exp(-(f - tBack) / 30) : 0;
  const earthDx = push * 0.9 + (f > tPush + 8 ? 5 * Math.sin((f - tPush) * 1.2) * Math.exp(-(f - tPush - 8) / 6) : 0);

  return (
    <Slot
      box={BOX.center}
      viewBox={[950, 1000]}
      label={f >= tLabel ? 'Siapa mendorong?' : null}
      labelSize={76}
      labelScale={pop(f, tLabel)}
      scale={slotScale(f, dur)}
      spin={ease(f, dur - 12, dur) * 140}
    >
      {MARKS.map((m, i) => {
        const t = at(1, m.word);
        const s = pop(f, t) * m.s;
        if (s <= 0.01) return null;
        return <Question key={i} x={m.x} y={m.y} s={s} color={i % 2 ? C.terra : C.amber} rot={8 * Math.sin(f * 0.12 + i * 1.7)} />;
      })}
      <g transform={`translate(${earthDx} 0)`}>
        <YarnGlobe cx={475} cy={540} r={290} spin={25} />
      </g>
      <Hand x={handX} y={540} rot={confused} />
    </Slot>
  );
};
