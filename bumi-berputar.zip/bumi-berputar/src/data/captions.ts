// Data caption: SRT mentah dari narasi. Semua waktu animasi dihitung dari sini.

/** Geser sinkron dalam detik. Positif = animasi/subtitle lebih lambat dari audio; negatif = lebih cepat. */
export const AUDIO_OFFSET = 0;

export const SRT_RAW = `1
00:00:00,100 --> 00:00:06,340
Sekarang ini, kamu lagi melaju sekitar
1.600 km/jam. Duduk diam di kasur pun,

2
00:00:06,340 --> 00:00:11,880
kamu tetap ngebut. Soalnya, bumi enggak
pernah berhenti berputar. Tapi kenapa

3
00:00:11,880 --> 00:00:16,560
bisa? Enggak ada mesin, enggak ada tali
yang memutarnya. Kita juga enggak merasa

4
00:00:16,560 --> 00:00:22,840
apa-apa. Terus, siapa yang dulu mendorong
bumi pertama kali? Jawabannya ada di awal

5
00:00:22,840 --> 00:00:28,640
tata surya. Sekitar 4,5 miliar tahun lalu,
awan gas dan debu runtuh karena

6
00:00:28,640 --> 00:00:34,640
gravitasinya sendiri. Awan itu berputar,
makin kecil, makin kencang. Dari situ,

7
00:00:34,640 --> 00:00:39,920
bumi terbentuk dan putarannya terbawa
sejak lahir. Di luar angkasa, enggak ada

8
00:00:39,920 --> 00:00:44,760
gesekan yang berarti. Jadi, putaran itu
nyaris enggak pernah padam. Bayangkan

9
00:00:44,760 --> 00:00:48,820
penari ice skating yang berputar sambil
merentangkan tangan. Begitu tangannya

10
00:00:48,820 --> 00:00:54,920
dirapatkan, putarannya makin kencang. Awan
tadi persis begitu. Dan kamu bisa lihat

11
00:00:54,920 --> 00:00:58,600
bukti putaran bumi di Bandara
Soekarno-Hatta. Pesawat yang terbang ke

12
00:00:58,600 --> 00:01:03,220
timur sedikit lebih cepat sampai dibanding
yang ke barat, karena arah angin dan

13
00:01:03,220 --> 00:01:08,640
putaran bumi ikut berpengaruh. Putaran ini
yang bikin ada siang dan malam. Satu

14
00:01:08,640 --> 00:01:14,940
putaran penuh makan waktu 24 jam. Lautan
juga ikut terdorong, jadi arus dan angin

15
00:01:14,940 --> 00:01:20,120
punya arah yang teratur. Tanpa putaran,
satu sisi bumi panggang terus, sisi

16
00:01:20,120 --> 00:01:25,760
lainnya beku. Bumi muter sejak sebelum ada
kehidupan dan enggak pernah minta izin

17
00:01:25,780 --> 00:01:27,260
siapa pun buat terus jalan.
`;
