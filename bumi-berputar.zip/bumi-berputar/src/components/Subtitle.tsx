import React from 'react';
import {useCurrentFrame} from 'remotion';
import {SUB_FONT, SUB_LINE_H, SUB_ZONE} from '../layout';
import {FONT, useTheme} from '../theme';
import {pop} from '../lib/anim';
import {SUB_PAGES, WORDS} from '../lib/timing';

/** Subtitle per kata, dari data SRT. Dua baris tetap, tidak pernah melewati zona subtitle. */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const theme = useTheme();
  const page = SUB_PAGES.find((p) => frame >= p.startF && frame < p.endF);
  if (!page) return null;

  return (
    <div
      style={{
        position: 'absolute',
        left: SUB_ZONE.x,
        top: SUB_ZONE.y,
        width: SUB_ZONE.w,
        height: SUB_ZONE.h,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {page.lines.map((line, li) => (
        <div key={li} style={{height: SUB_LINE_H, whiteSpace: 'nowrap', fontFamily: FONT, fontWeight: 800, fontSize: SUB_FONT, lineHeight: `${SUB_LINE_H}px`}}>
          {line.map((wi, k) => {
            const w = WORDS[wi];
            const spoken = frame >= w.startF;
            const current = spoken && frame < w.endF;
            const s = current ? 1 + 0.08 * Math.min(1, pop(frame, w.startF, 14, 200)) : 1;
            return (
              <span
                key={wi}
                style={{
                  display: 'inline-block',
                  marginLeft: k ? SUB_FONT * 0.28 : 0,
                  color: current ? theme.accent : theme.ink,
                  opacity: spoken ? 1 : 0.35,
                  transform: `scale(${s})`,
                }}
              >
                {w.text}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};
