import React from 'react';
import {LABEL_GAP, LABEL_H, Rect} from '../layout';
import {FONT, useTheme} from '../theme';

/**
 * Satu wadah: objek (SVG dengan viewBox sendiri, dipotong di kotaknya) + label tepat di bawahnya.
 * Keduanya bergerak/mengecil bersama. Posisi semua eksplisit.
 */
export const Slot: React.FC<{
  box: Rect;
  viewBox: [number, number];
  label?: string | null;
  labelSize?: number;
  labelScale?: number;
  labelColor?: string;
  scale?: number;
  spin?: number;
  children: React.ReactNode;
}> = ({box, viewBox, label, labelSize = 76, labelScale = 1, labelColor, scale = 1, spin = 0, children}) => {
  const theme = useTheme();
  const [vw, vh] = viewBox;
  if (scale <= 0.001) return null;

  // Huruf label diperkecil otomatis bila perkiraan lebarnya melebihi lebar slot.
  const chars = label ? label.length : 0;
  const size = chars ? Math.min(labelSize, (box.w * 0.94) / (chars * 0.62)) : labelSize;

  return (
    <div
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h + LABEL_GAP + LABEL_H,
        transform: `scale(${scale})`,
        transformOrigin: `50% ${box.h / 2}px`,
      }}
    >
      <svg
        width={box.w}
        height={box.h}
        viewBox={`0 0 ${vw} ${vh}`}
        style={{position: 'absolute', left: 0, top: 0, overflow: 'hidden', display: 'block'}}
      >
        <g transform={`rotate(${spin} ${vw / 2} ${vh / 2})`}>{children}</g>
      </svg>
      {label ? (
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: box.h + LABEL_GAP,
            width: box.w,
            height: LABEL_H,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: size,
              lineHeight: 1.1,
              whiteSpace: 'nowrap',
              color: labelColor ?? theme.ink,
              borderBottom: `8px dashed ${theme.accent}`,
              paddingBottom: 4,
              transform: `scale(${labelScale})`,
            }}
          >
            {label}
          </div>
        </div>
      ) : null}
    </div>
  );
};
