import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, SUB_ZONE, W} from '../layout';
import {seeded} from '../lib/rand';
import {C, useTheme} from '../theme';
import {Knot} from '../lib/yarn';

const rnd = seeded(20261106);
const STARS = Array.from({length: 46}, () => ({
  x: 90 + rnd() * (W - 180),
  y: 140 + rnd() * (SUB_ZONE.y - 190),
  r: 3 + rnd() * 6,
  ph: rnd() * 6.28,
  c: rnd() > 0.5 ? C.amber : C.cream,
}));

/** Latar datar yang berganti siang/malam/angkasa, dengan pola jahitan rajut halus dan bintang dari simpul benang. */
export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const theme = useTheme();
  return (
    <AbsoluteFill style={{backgroundColor: theme.bg}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <pattern id="rajut" width="36" height="30" patternUnits="userSpaceOnUse">
            <path d="M5 5 L18 24 L31 5" fill="none" stroke={theme.ink} strokeOpacity={0.07} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
          </pattern>
        </defs>
        <rect x={0} y={0} width={W} height={H} fill="url(#rajut)" />
        {theme.space > 0.01 && (
          <g opacity={theme.space}>
            {STARS.map((s, i) => (
              <Knot key={i} cx={s.x} cy={s.y} r={s.r * (0.85 + 0.15 * Math.sin(frame * 0.08 + s.ph))} color={s.c} />
            ))}
          </g>
        )}
      </svg>
    </AbsoluteFill>
  );
};
