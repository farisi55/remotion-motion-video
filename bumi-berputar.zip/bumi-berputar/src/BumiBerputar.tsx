import React from 'react';
import {AbsoluteFill, interpolate, interpolateColors, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {Background} from './components/Background';
import {Subtitle} from './components/Subtitle';
import {Beat1Hook} from './beats/Beat1Hook';
import {Beat2Masalah} from './beats/Beat2Masalah';
import {Beat3Inti} from './beats/Beat3Inti';
import {Beat4Contoh} from './beats/Beat4Contoh';
import {Beat5Dampak} from './beats/Beat5Dampak';
import {Beat6Penutup} from './beats/Beat6Penutup';
import {BEATS, TOTAL_FRAMES} from './lib/timing';
import {C, Theme, ThemeContext} from './theme';

const BEAT_COMPONENTS = [Beat1Hook, Beat2Masalah, Beat3Inti, Beat4Contoh, Beat5Dampak, Beat6Penutup];

const keyed = (frame: number, keys: [number, number][]) =>
  interpolate(
    frame,
    keys.map((k) => k[0]),
    keys.map((k) => k[1]),
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'},
  );

const useThemeAt = (frame: number): Theme => {
  const b = BEATS.map((x) => x.from);
  // siang -> malam (beat 2-3) -> siang (beat 4-5) -> angkasa gelap (beat 6)
  const dark = keyed(frame, [
    [0, 0],
    [b[1] - 10, 0],
    [b[1] + 6, 1],
    [b[3] - 10, 1],
    [b[3] + 6, 0],
    [b[5], 0],
    [b[5] + 75, 1],
  ]);
  // bintang simpul benang: hanya di angkasa (beat 3 dan beat 6), meredup di akhir
  const space = keyed(frame, [
    [0, 0],
    [b[2] - 10, 0],
    [b[2] + 6, 1],
    [b[3] - 10, 1],
    [b[3], 0],
    [b[5] + 30, 0],
    [b[5] + 90, 1],
    [TOTAL_FRAMES - 45, 1],
    [TOTAL_FRAMES, 0.25],
  ]);
  return {
    bg: interpolateColors(dark, [0, 1], [C.cream, C.plum]),
    ink: interpolateColors(dark, [0, 1], [C.plum, C.cream]),
    accent: interpolateColors(dark, [0, 1], [C.terra, C.amber]),
    dark,
    space,
  };
};

export const BumiBerputar: React.FC = () => {
  const frame = useCurrentFrame();
  const theme = useThemeAt(frame);
  return (
    <ThemeContext.Provider value={theme}>
      <AbsoluteFill>
        <Background />
        {BEATS.map((beat, i) => {
          const Comp = BEAT_COMPONENTS[i];
          return (
            <Sequence key={beat.id} name={`Beat ${i + 1} - ${beat.id}`} from={beat.from} durationInFrames={beat.duration}>
              <Comp />
            </Sequence>
          );
        })}
        <Subtitle />
        <Audio src={staticFile('narasi.mp3')} />
      </AbsoluteFill>
    </ThemeContext.Provider>
  );
};
