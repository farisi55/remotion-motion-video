import React from 'react';

export const C = {
  amber: '#E8B04A',
  terra: '#D2553F',
  teal: '#2F6F8F',
  cream: '#F2E6CF',
  plum: '#3B2A4A',
} as const;

export const FONT = "'Trebuchet MS', 'Segoe UI', Verdana, Arial, sans-serif";

/** Warna latar/teks yang berubah mengikuti siang (cream), malam (plum), dan angkasa (plum + bintang simpul). */
export type Theme = {bg: string; ink: string; accent: string; dark: number; space: number};

export const ThemeContext = React.createContext<Theme>({
  bg: C.cream,
  ink: C.plum,
  accent: C.terra,
  dark: 0,
  space: 0,
});

export const useTheme = () => React.useContext(ThemeContext);
