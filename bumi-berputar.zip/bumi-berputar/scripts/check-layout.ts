// Pemeriksa tata letak (opsional, hanya untuk pengembang).
// Jalankan: node scripts/check-layout.ts   (Node 22.18+)  -> menulis docs/TATA-LETAK.md
import {writeFileSync} from 'node:fs';
import {BOX, SAFE, SUB_ZONE, MIN_SLOT_GAP, labelBox, lerpRect, W, H} from '../src/layout.ts';
import type {Rect} from '../src/layout.ts';

type Item = {name: string; r: Rect};
type Moment = {beat: string; moment: string; items: Item[]; slotPairs?: [string, string][]};

const obj = (name: string, r: Rect): Item[] => [
  {name: `${name} (objek)`, r},
  {name: `${name} (label)`, r: labelBox(r)},
];
const sub: Item = {name: 'subtitle', r: SUB_ZONE};

const moments: Moment[] = [
  {beat: '1 Hook', moment: 'masuk / tampil / keluar', items: [...obj('bumi+kasur', BOX.center), sub]},
  {beat: '2 Masalah', moment: 'masuk / tampil / keluar', items: [...obj('bumi+tangan', BOX.center), sub]},
  {beat: '3 Inti', moment: 'masuk / tampil / keluar', items: [...obj('awan gas -> bumi', BOX.center), sub]},
  {beat: '4a Contoh', moment: 'penari di tengah', items: [...obj('penari', BOX.skaterCenter), sub]},
  ...[0.25, 0.5, 0.75, 1].map((t) => ({
    beat: '4b Contoh',
    moment: `penari bergeser ke kiri t=${t} (awan belum masuk)`,
    items: [...obj('penari', lerpRect(BOX.skaterCenter, BOX.skaterLeft, t)), sub],
  })),
  {
    beat: '4c Contoh',
    moment: 'penari kiri + awan kanan',
    items: [...obj('penari', BOX.skaterLeft), ...obj('awan', BOX.cloudRight), sub],
    slotPairs: [['penari (objek)', 'awan (objek)']],
  },
  {beat: '4d Contoh', moment: 'peta + pesawat', items: [...obj('peta', BOX.map), sub]},
  {beat: '5 Dampak', moment: 'masuk / tampil / keluar', items: [...obj('bumi+jam', BOX.center), sub]},
  ...[0, 0.25, 0.5, 0.75, 1].map((t) => ({
    beat: '6 Penutup',
    moment: `bumi menjauh t=${t}`,
    items: [...obj('bumi->titik', lerpRect(BOX.center, BOX.closingEnd, t)), sub],
  })),
];

const overlap = (a: Rect, b: Rect) =>
  a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
const inside = (a: Rect, s: Rect) =>
  a.x >= s.x - 0.01 && a.y >= s.y - 0.01 && a.x + a.w <= s.x + s.w + 0.01 && a.y + a.h <= s.y + s.h + 0.01;

let errors = 0;
const fmt = (n: number) => Math.round(n * 10) / 10;
let md = `# Tabel koordinat tata letak (kanvas ${W}x${H})\n\n`;
md += `- Margin aman 6%: x ${SAFE.x}..${SAFE.x + SAFE.w}, y ${SAFE.y}..${SAFE.y + SAFE.h}\n`;
md += `- Zona subtitle (18% tinggi = ${SUB_ZONE.h}px): x ${SUB_ZONE.x}, y ${SUB_ZONE.y}, w ${SUB_ZONE.w}, h ${SUB_ZONE.h}\n`;
md += `- Jarak minimal antar slot yang tampil bersamaan: ${MIN_SLOT_GAP.toFixed(1)}px (8%)\n\n`;
md += '| Beat | Momen | Elemen | x | y | w | h | Hasil |\n|---|---|---|---|---|---|---|---|\n';

for (const m of moments) {
  m.items.forEach((it, i) => {
    let status = 'OK';
    if (!inside(it.r, SAFE)) { status = 'DI LUAR MARGIN AMAN'; errors++; }
    for (let j = 0; j < m.items.length; j++) {
      if (j !== i && overlap(it.r, m.items[j].r)) { status = `TUMPANG TINDIH dengan ${m.items[j].name}`; errors++; }
    }
    if (it.name.endsWith('(label)')) {
      const o = m.items[i - 1];
      if (it.r.w > o.r.w + 0.01) { status = 'LABEL LEBIH LEBAR DARI SLOT'; errors++; }
    }
    md += `| ${m.beat} | ${m.moment} | ${it.name} | ${fmt(it.r.x)} | ${fmt(it.r.y)} | ${fmt(it.r.w)} | ${fmt(it.r.h)} | ${status} |\n`;
  });
  for (const [a, b] of m.slotPairs ?? []) {
    const ra = m.items.find((i) => i.name === a)!.r;
    const rb = m.items.find((i) => i.name === b)!.r;
    const gap = rb.x - (ra.x + ra.w);
    const ok = gap >= MIN_SLOT_GAP;
    if (!ok) errors++;
    md += `| ${m.beat} | ${m.moment} | jarak horizontal slot | ${fmt(gap)} | | | | ${ok ? 'OK (>= 86.4)' : 'KURANG DARI 8%'} |\n`;
  }
}

md += `\nObjek dibatasi kotaknya oleh SVG dengan overflow hidden, sehingga isi objek tidak bisa keluar dari kotak.\n`;
md += `\nTotal pelanggaran: **${errors}**\n`;
writeFileSync(new URL('../docs/TATA-LETAK.md', import.meta.url), md);
console.log(errors === 0 ? 'Tata letak OK, tanpa tumpang tindih.' : `Ada ${errors} pelanggaran, lihat docs/TATA-LETAK.md`);
process.exit(errors === 0 ? 0 : 1);
