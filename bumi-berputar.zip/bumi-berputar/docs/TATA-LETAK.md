# Tabel koordinat tata letak (kanvas 1080x1920)

- Margin aman 6%: x 65..1015, y 115..1805
- Zona subtitle (18% tinggi = 346px): x 65, y 1459, w 950, h 346
- Jarak minimal antar slot yang tampil bersamaan: 86.4px (8%)

| Beat | Momen | Elemen | x | y | w | h | Hasil |
|---|---|---|---|---|---|---|---|
| 1 Hook | masuk / tampil / keluar | bumi+kasur (objek) | 65 | 130 | 950 | 1000 | OK |
| 1 Hook | masuk / tampil / keluar | bumi+kasur (label) | 65 | 1140 | 950 | 120 | OK |
| 1 Hook | masuk / tampil / keluar | subtitle | 65 | 1459 | 950 | 346 | OK |
| 2 Masalah | masuk / tampil / keluar | bumi+tangan (objek) | 65 | 130 | 950 | 1000 | OK |
| 2 Masalah | masuk / tampil / keluar | bumi+tangan (label) | 65 | 1140 | 950 | 120 | OK |
| 2 Masalah | masuk / tampil / keluar | subtitle | 65 | 1459 | 950 | 346 | OK |
| 3 Inti | masuk / tampil / keluar | awan gas -> bumi (objek) | 65 | 130 | 950 | 1000 | OK |
| 3 Inti | masuk / tampil / keluar | awan gas -> bumi (label) | 65 | 1140 | 950 | 120 | OK |
| 3 Inti | masuk / tampil / keluar | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4a Contoh | penari di tengah | penari (objek) | 215 | 150 | 650 | 900 | OK |
| 4a Contoh | penari di tengah | penari (label) | 215 | 1060 | 650 | 120 | OK |
| 4a Contoh | penari di tengah | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.25 (awan belum masuk) | penari (objek) | 177.5 | 195 | 590 | 817 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.25 (awan belum masuk) | penari (label) | 177.5 | 1022 | 590 | 120 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.25 (awan belum masuk) | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.5 (awan belum masuk) | penari (objek) | 140 | 240 | 530 | 734 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.5 (awan belum masuk) | penari (label) | 140 | 984 | 530 | 120 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.5 (awan belum masuk) | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.75 (awan belum masuk) | penari (objek) | 102.5 | 285 | 470 | 651 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.75 (awan belum masuk) | penari (label) | 102.5 | 946 | 470 | 120 | OK |
| 4b Contoh | penari bergeser ke kiri t=0.75 (awan belum masuk) | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4b Contoh | penari bergeser ke kiri t=1 (awan belum masuk) | penari (objek) | 65 | 330 | 410 | 568 | OK |
| 4b Contoh | penari bergeser ke kiri t=1 (awan belum masuk) | penari (label) | 65 | 908 | 410 | 120 | OK |
| 4b Contoh | penari bergeser ke kiri t=1 (awan belum masuk) | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4c Contoh | penari kiri + awan kanan | penari (objek) | 65 | 330 | 410 | 568 | OK |
| 4c Contoh | penari kiri + awan kanan | penari (label) | 65 | 908 | 410 | 120 | OK |
| 4c Contoh | penari kiri + awan kanan | awan (objek) | 605 | 330 | 410 | 568 | OK |
| 4c Contoh | penari kiri + awan kanan | awan (label) | 605 | 908 | 410 | 120 | OK |
| 4c Contoh | penari kiri + awan kanan | subtitle | 65 | 1459 | 950 | 346 | OK |
| 4c Contoh | penari kiri + awan kanan | jarak horizontal slot | 130 | | | | OK (>= 86.4) |
| 4d Contoh | peta + pesawat | peta (objek) | 65 | 300 | 950 | 700 | OK |
| 4d Contoh | peta + pesawat | peta (label) | 65 | 1010 | 950 | 120 | OK |
| 4d Contoh | peta + pesawat | subtitle | 65 | 1459 | 950 | 346 | OK |
| 5 Dampak | masuk / tampil / keluar | bumi+jam (objek) | 65 | 130 | 950 | 1000 | OK |
| 5 Dampak | masuk / tampil / keluar | bumi+jam (label) | 65 | 1140 | 950 | 120 | OK |
| 5 Dampak | masuk / tampil / keluar | subtitle | 65 | 1459 | 950 | 346 | OK |
| 6 Penutup | bumi menjauh t=0 | bumi->titik (objek) | 65 | 130 | 950 | 1000 | OK |
| 6 Penutup | bumi menjauh t=0 | bumi->titik (label) | 65 | 1140 | 950 | 120 | OK |
| 6 Penutup | bumi menjauh t=0 | subtitle | 65 | 1459 | 950 | 346 | OK |
| 6 Penutup | bumi menjauh t=0.25 | bumi->titik (objek) | 121.3 | 217.5 | 837.5 | 881.5 | OK |
| 6 Penutup | bumi menjauh t=0.25 | bumi->titik (label) | 121.3 | 1109 | 837.5 | 120 | OK |
| 6 Penutup | bumi menjauh t=0.25 | subtitle | 65 | 1459 | 950 | 346 | OK |
| 6 Penutup | bumi menjauh t=0.5 | bumi->titik (objek) | 177.5 | 305 | 725 | 763 | OK |
| 6 Penutup | bumi menjauh t=0.5 | bumi->titik (label) | 177.5 | 1078 | 725 | 120 | OK |
| 6 Penutup | bumi menjauh t=0.5 | subtitle | 65 | 1459 | 950 | 346 | OK |
| 6 Penutup | bumi menjauh t=0.75 | bumi->titik (objek) | 233.8 | 392.5 | 612.5 | 644.5 | OK |
| 6 Penutup | bumi menjauh t=0.75 | bumi->titik (label) | 233.8 | 1047 | 612.5 | 120 | OK |
| 6 Penutup | bumi menjauh t=0.75 | subtitle | 65 | 1459 | 950 | 346 | OK |
| 6 Penutup | bumi menjauh t=1 | bumi->titik (objek) | 290 | 480 | 500 | 526 | OK |
| 6 Penutup | bumi menjauh t=1 | bumi->titik (label) | 290 | 1016 | 500 | 120 | OK |
| 6 Penutup | bumi menjauh t=1 | subtitle | 65 | 1459 | 950 | 346 | OK |

Objek dibatasi kotaknya oleh SVG dengan overflow hidden, sehingga isi objek tidak bisa keluar dari kotak.

Total pelanggaran: **0**
