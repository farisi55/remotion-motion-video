# Bagaimana Bumi Bisa Berputar (Remotion)

Video 9:16 (1080x1920), 30 fps, gaya Gasing Benang Warna. Durasi dihitung dari SRT: kata terakhir selesai + 1 detik (88,27 detik = 2648 frame).

## Jalankan
```
npm install
npm run dev      # pratinjau di browser (Remotion Studio)
npm run render   # hasil: out/bumi-berputar.mp4
```

## Yang perlu kamu ganti
- `public/narasi.mp3` saat ini file HENING sebagai pengganti. Timpa dengan rekaman narasimu (nama file harus sama).
- Jika suara terdengar lebih cepat/lambat dari animasi, ubah `AUDIO_OFFSET` (detik) di `src/data/captions.ts`.

## Struktur
- `src/data/captions.ts` : SRT mentah + AUDIO_OFFSET (satu-satunya sumber waktu)
- `src/lib/timing.ts`    : SRT -> waktu per kata (proporsional jumlah huruf), durasi beat, halaman subtitle
- `src/layout.ts`        : semua koordinat eksplisit; tabel pemeriksaan di `docs/TATA-LETAK.md`
- `src/beats/`           : satu komponen per beat, dibungkus Sequence di `src/BumiBerputar.tsx`
- `src/objects/`         : bumi, awan gas, penari, peta, tangan (semua dari benang SVG)
